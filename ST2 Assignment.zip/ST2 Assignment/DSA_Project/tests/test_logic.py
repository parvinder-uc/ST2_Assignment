import unittest
import sys
import os


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


from modules.data_structures import Stack, insert_bst
from modules.heap_visualiser import MinHeap
from modules.dp_visualiser import count_paths, astar


class TestDSAExplorer(unittest.TestCase):

    # PHASE 1: Data Structures
    def test_stack(self):
        stack = Stack()
        stack.push("A")
        self.assertEqual(stack.pop(), "A")

    def test_bst(self):
        root = insert_bst(None, 50)
        root = insert_bst(root, 30)
        self.assertEqual(root.left.data, 30)

    def test_heap(self):
        heap = MinHeap()
        heap.insert(100)
        heap.insert(20)
        self.assertEqual(heap.heap[0], 20)

    # PHASE 2: Algorithms

    def test_bubble_sort_logic(self):
        arr = [5, 3, 1, 4, 2]

        # simple reference sort
        expected = sorted(arr)

        # simulate bubble sort result indirectly
        arr.sort()

        self.assertEqual(arr, expected)

    def test_bfs_graph_logic(self):
        # simplified BFS structure test
        graph = {
            'A': ['B', 'C'],
            'B': ['A'],
            'C': ['A']
        }

        visited = []
        queue = ['A']

        while queue:
            node = queue.pop(0)
            if node not in visited:
                visited.append(node)
                for n in graph[node]:
                    if n not in visited:
                        queue.append(n)

        self.assertIn('A', visited)
        self.assertIn('B', visited)

    # PHASE 3: Puzzles
    def test_dp_count_paths(self):
        result = count_paths(3, 3)
        self.assertEqual(result[2][2], 6)  # known DP result

    def test_astar_pathfinding(self):
        grid = [
            [0, 0],
            [0, 0]
        ]

        start = (0, 0)
        end = (1, 1)

        visited, path = astar(grid, start, end)

        self.assertTrue(end in path)
        self.assertTrue(start in path)


if __name__ == "__main__":
    unittest.main()