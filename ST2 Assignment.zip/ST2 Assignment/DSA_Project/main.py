import pygame
import sys

from modules.data_structures import data_structures_module
from modules.sorting_visualiser import sorting_module
from modules.graph_visualiser import graphs_module
from modules.heap_visualiser import heap_module
from modules.dp_visualiser import puzzles_module

pygame.init()

WIDTH, HEIGHT = 1050,750
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Algorithm Explorer")
FONT = pygame.font.SysFont(None, 36)
clock = pygame.time.Clock()


def draw_text(text, pos):

    txt = FONT.render(text, True, (0, 0, 0))
    screen.blit(txt, pos)


def main_menu():

    # Title Name Algorithm Explorer
    screen.fill((200, 200, 250))
    draw_text("Algorithm Explorer", (WIDTH // 2.6, 50))

    
    buttons = {
        # button size
        'Data Structures': pygame.Rect(400, 150, 200, 50),  # Week 10 & 11
        'Sorting': pygame.Rect(400, 230, 200, 50),  # Week 11
        'Graphs': pygame.Rect(400, 310, 200, 50),  # Week 12
        'Heap': pygame.Rect(400, 390, 200, 50),  # Week 12
        'Puzzles': pygame.Rect(400, 470, 200, 50)  # Week 12
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, (150, 150, 200), rect)
        draw_text(text, (rect.x + 20, rect.y + 10))

    pygame.display.flip()
    return buttons


def main():

    running = True
    current_module = None
    buttons = main_menu()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # EVENT HANDLING
            elif event.type == pygame.MOUSEBUTTONDOWN and current_module is None:
                pos = event.pos
                for name, rect in buttons.items():
                    if rect.collidepoint(pos):
                        current_module = name

        #  MODULE EXECUTION WEEKS 10, 11, 12
        if current_module:
            if current_module == 'Data Structures':
               # Stack, Linked List and BST
                data_structures_module(screen, clock)

            elif current_module == 'Sorting':
                # Bubble, Selection and Merge
                sorting_module(screen, clock)

            elif current_module == 'Graphs':
                # BFS and DFS
                graphs_module(screen, clock)

            elif current_module == 'Heap':
                # Heaps and Priority Queues
                heap_module(screen, clock)

            elif current_module == 'Puzzles':
                # DP Puzzles and Pathfinding
                puzzles_module(screen, clock)

            # After module ends, return to menu
            current_module = None
            buttons = main_menu()

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()