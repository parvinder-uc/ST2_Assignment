import pygame

# DFS Function
def dfs(graph, node, visited):

    if node not in visited:

        visited.append(node)

        for neighbor in graph[node]:
            dfs(graph, neighbor, visited)
def graphs_module(screen, clock):

    font = pygame.font.SysFont(None, 24)
    
    # Node Positions
    nodes_pos = {
        'A': (150, 150),
        'B': (300, 100),
        'C': (150, 300),
        'D': (300, 300),
        'E': (450, 200),
        'F': (600, 200)
    }

    # Graph
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'D'],
        'D': ['B', 'C', 'E'],
        'E': ['B', 'D', 'F'],
        'F': ['E']
    }
    #Array
    visited = []
    queue = []
    searching = False
    search_mode = None

    message = "( BFS = B ) ( DFS = D ) ( Reset = R ) ( Menu = ESC )"

    running = True

    while running:

        screen.fill((255, 255, 255))

        # Draw Edges
        for start_node, neighbors in graph.items():

            for end_node in neighbors:
                pygame.draw.line(
                    screen,
                    (180, 180, 180),
                    nodes_pos[start_node],
                    nodes_pos[end_node],
                    2
                )

        for node, pos in nodes_pos.items():

            color = (220, 220, 220)
            if node in visited:
                color = (100, 255, 100)
            elif node in queue:
                color = (255, 255, 100)

            pygame.draw.circle(screen, color, pos, 25)
            pygame.draw.circle(screen, (0, 0, 0), pos, 25, 2)

            node_txt = font.render(node, True, (0, 0, 0))
            screen.blit(node_txt, (pos[0] - 8, pos[1] - 10))
        instr_txt = font.render(message, True, (50, 50, 50))
        screen.blit(instr_txt, (20, 20))

        # Events
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                # Start BFS
                if event.key == pygame.K_b and not searching:

                    searching = True
                    search_mode = "BFS"
                    visited = []
                    queue = ['A']
                    message = "BFS Running "
                    
                # Start DFS
                if event.key == pygame.K_d and not searching:
                    searching = True
                    search_mode = "DFS"
                    visited = []
                    dfs(graph, 'A', visited)
                    searching = False
                    message = "DFS Complete ( Reset = R )"

                # Reset
                if event.key == pygame.K_r:
                    
                    visited = []
                    queue = []
                    searching = False
                    search_mode = None
                    message = "( BFS = B ) ( DFS = D ) ( Reset = R ) ( Menu = ESC )"

        # BFS Logic
        if searching and search_mode == "BFS":

            if queue:

                pygame.time.delay(600)
                current = queue.pop(0)

                if current not in visited:
                    visited.append(current)
                    for neighbor in graph[current]:
                        if neighbor not in visited and neighbor not in queue:
                            queue.append(neighbor)
            else:
                searching = False
                message = "BFS Complete ( Reset = R )"

        pygame.display.flip()
        clock.tick(30)