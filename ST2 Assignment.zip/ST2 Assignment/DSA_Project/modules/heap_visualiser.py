import pygame
import random


class MinHeap:

    def __init__(self):
        self.heap = []

    # Insert
    def insert(self, val):
        self.heap.append(val)
        self._bubble_up(len(self.heap) - 1)

    # Buble up
    def _bubble_up(self, index):

        parent = (index - 1) // 2

        if index > 0 and self.heap[index] < self.heap[parent]:

            self.heap[index], self.heap[parent] = self.heap[parent], self.heap[index]
            self._bubble_up(parent)

    def extract_min(self):

        if len(self.heap) == 0:
            return None

        if len(self.heap) == 1:
            return self.heap.pop()

        root = self.heap[0]

        self.heap[0] = self.heap.pop()

        self._heapify_down(0)

        return root

    def _heapify_down(self, index):
    
        smallest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < len(self.heap) and self.heap[left] < self.heap[smallest]:
            smallest = left

        if right < len(self.heap) and self.heap[right] < self.heap[smallest]:
            smallest = right

        if smallest != index:
            self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
            self._heapify_down(smallest)

def heap_module(screen, clock):

    font = pygame.font.SysFont(None, 24)

    min_heap = MinHeap()

    message = "( I = Insert ) ( E = Extract ) ( R = Reset ) ( ESC = Menu )"

    running = True

    while running:

        screen.fill((255, 255, 255))

        # TEXT
        instr_txt = font.render(message, True, (50, 50, 50))
        screen.blit(instr_txt, (20, 20))

        positions = {}

        # Fixed Screen
        if len(min_heap.heap) > 0:

            level_height = 90
            screen_width = 800

            for i, val in enumerate(min_heap.heap):

                level = i.bit_length() - 1
                level_start = (2 ** level) - 1
                pos_in_level = i - level_start
                level_width = 2 ** level

                spacing = screen_width // (level_width + 1)

                x = spacing * (pos_in_level + 1)
                y = 120 + level * level_height

                positions[i] = (int(x), int(y))

             # Draw Node
        for i, val in enumerate(min_heap.heap):

            if i in positions:

                x, y = positions[i]

                pygame.draw.circle(screen, (200, 150, 255), (x, y), 20)
                pygame.draw.circle(screen, (0, 0, 0), (x, y), 20, 2)

                txt = font.render(str(val), True, (0, 0, 0))
                screen.blit(txt, (x - 10, y - 10))

        #   Event
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                # Insert
                if event.key == pygame.K_i:
                    val = random.randint(1, 99)
                    min_heap.insert(val)
                    message = f"Inserted {val} ( I = Insert ) ( E = Extract )"

                # Extract
                if event.key == pygame.K_e:
                    removed = min_heap.extract_min()
                    message = f"Extract {removed}" if removed else "Heap Empty"

                # Reset
                if event.key == pygame.K_r:
                    min_heap = MinHeap()
                    message = "( I = Insert ) ( E = Extract ) ( R = Reset )"

        pygame.display.flip()
        clock.tick(30)