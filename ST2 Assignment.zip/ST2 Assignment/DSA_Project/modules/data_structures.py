import pygame
import random

# NODE
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.left = None
        self.right = None
# STACK
class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if self.items:
            return self.items.pop()
        return None
# QUEUE
class Queue:
    def __init__(self):
        self.items = []

    def enqueue(self, item):
        self.items.insert(0, item)

    def dequeue(self):
        if self.items:
            return self.items.pop()
        return None
# Linked List
class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return

        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def delete(self, value):
        current = self.head

        if current and current.data == value:
            self.head = current.next
            return

        prev = None
        while current and current.data != value:
            prev = current
            current = current.next

        if current:
            prev.next = current.next
# BST
def insert_bst(root, data):
    if root is None:
        return Node(data)

    if data < root.data:
        root.left = insert_bst(root.left, data)
    else:
        root.right = insert_bst(root.right, data)

    return root
# Tree Traversal
def inorder(root, result):
    if root:
        inorder(root.left, result)
        result.append(root.data)
        inorder(root.right, result)
# Draw tree
def draw_tree(screen, node, x, y, spacing, font):
    if node:
        if node.left:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x - spacing, y + 60), 2)
            draw_tree(screen, node.left, x - spacing, y + 60, spacing // 2, font)

        if node.right:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x + spacing, y + 60), 2)
            draw_tree(screen, node.right, x + spacing, y + 60, spacing // 2, font)

        pygame.draw.circle(screen, (255, 200, 100), (x, y), 20)
        pygame.draw.circle(screen, (0, 0, 0), (x, y), 20, 2)

        txt = font.render(str(node.data), True, (0, 0, 0))
        screen.blit(txt, (x - 10, y - 10))
# Main Mode
def data_structures_module(screen, clock):
    font = pygame.font.SysFont(None, 28)

    stack = Stack()
    queue = Queue()
    bst_root = None
    
    mode = "STACK"
    running = True
    while running:
        screen.fill((255, 255, 255))
    
        if mode == "STACK":
            message = "STACK ( Push = P ) ( Pop = O ) ( Toggle = T ) ( Menu = ESC )"
        elif mode == "QUEUE":
            message = "QUEUE ( Enqueue = P ) ( Dequeue = O ) ( Toggle = T ) ( Menu = ESC )"
        elif mode == "BST":
            message = "BST ( Insert = P ) ( Toggle = T ) ( Menu = ESC )"

        screen.blit(font.render(f"Mode: {mode}", True, (0, 0, 0)), (20, 20))
        screen.blit(font.render(message, True, (50, 50, 50)), (20, 50))
   
        # Stack Visual
        if mode == "STACK":
            pygame.draw.rect(screen, (0, 0, 0), (300, 150, 200, 350), 2)

            for i, v in enumerate(stack.items):
                rect = pygame.Rect(310, 460 - (i * 45), 180, 40)
                pygame.draw.rect(screen, (100, 150, 250), rect)

                txt = font.render(str(v), True, (255, 255, 255))
                screen.blit(txt, (rect.x + 70, rect.y + 10))
  
        # Queue Visual
        elif mode == "QUEUE":

            for i, v in enumerate(queue.items):
                rect = pygame.Rect(310 + (i * 50), 300, 40, 40)
                pygame.draw.rect(screen, (200, 120, 120), rect)

                txt = font.render(str(v), True, (255, 255, 255))
                screen.blit(txt, (rect.x + 10, rect.y + 10))

        # BST Visual
        elif mode == "BST":
            if bst_root:
                draw_tree(screen, bst_root, 400, 150, 150, font)

        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_t:
                    modes = ["STACK", "QUEUE", "BST"]
                    mode = modes[(modes.index(mode) + 1) % len(modes)]

                elif event.key == pygame.K_p:
                    val = random.randint(1, 99)

                    if mode == "STACK":
                        stack.push(val)
                    elif mode == "QUEUE":
                        queue.enqueue(val)
                    else:
                        bst_root = insert_bst(bst_root, val)

                elif event.key == pygame.K_o:
                    if mode == "STACK":
                        stack.pop()
                    elif mode == "QUEUE":
                        queue.dequeue()
        pygame.display.flip()
        clock.tick(30)