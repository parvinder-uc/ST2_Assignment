import pygame
import heapq

# DP Logic
def count_paths(rows, cols):
    dp = [[0 for _ in range(cols)] for _ in range(rows)]

    for i in range(rows):
        dp[i][0] = 1
    for j in range(cols):
        dp[0][j] = 1

    for i in range(1, rows):
        for j in range(1, cols):
            dp[i][j] = dp[i-1][j] + dp[i][j-1]

    return dp

def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(grid, start, end):
    pq = []
    heapq.heappush(pq, (0, start))

    came_from = {}
    g_score = {start: 0}
    visited = []

    while pq:
        _, current = heapq.heappop(pq)

        if current == end:
            break

        visited.append(current)

        x, y = current
        neighbors = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]

        for nx, ny in neighbors:
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]):

                if grid[nx][ny] == 1:
                    continue

                temp_g = g_score[current] + 1

                if (nx, ny) not in g_score or temp_g < g_score[(nx, ny)]:
                    g_score[(nx, ny)] = temp_g
                    f = temp_g + heuristic((nx, ny), end)
                    heapq.heappush(pq, (f, (nx, ny)))
                    came_from[(nx, ny)] = current

    path = []
    node = end

    while node in came_from:
        path.append(node)
        node = came_from[node]

    path.append(start)
    path.reverse()

    return visited, path

def puzzles_module(screen, clock):

    font = pygame.font.SysFont(None, 24)

    rows, cols = 5, 5

    # DP Table
    dp_table = count_paths(rows, cols)

    # Pathfinding Grid
    grid = [[0 for _ in range(cols)] for _ in range(rows)]

    start = (0, 0)
    end = (rows-1, cols-1)

    visited = []
    path = []

    mode = "DP"

    message = "( Switch Mode DP Or Path = T ) ( Solve = Space ) ( On PATH = Click + SPACE )  ( Menu = ESC )"

    running = True

    while running:

        screen.fill((255, 255, 255))

        size = 80

        # TITLE
        screen.blit(font.render(f"Puzzle Module - {mode}", True, (0,0,0)), (20, 10))

        # DP Mode
        if mode == "DP":

            for i in range(rows):
                for j in range(cols):

                    rect = pygame.Rect(200 + j*size, 100 + i*size, size, size)

                    pygame.draw.rect(screen, (200, 230, 255), rect)
                    pygame.draw.rect(screen, (0,0,0), rect, 1)

                    txt = font.render(str(dp_table[i][j]), True, (0,0,0))
                    screen.blit(txt, (rect.x + 25, rect.y + 25))
        else:

            for i in range(rows):
                for j in range(cols):

                    rect = pygame.Rect(200 + j*size, 100 + i*size, size, size)

                    color = (220, 220, 220)

                    if grid[i][j] == 1:
                        color = (50, 50, 50)
                    if (i, j) in visited:
                        color = (150, 220, 255)
                    if (i, j) in path:
                        color = (0, 255, 0)
                    if (i, j) == start:
                        color = (255, 200, 0)
                    if (i, j) == end:
                        color = (255, 0, 0)

                    pygame.draw.rect(screen, color, rect)
                    pygame.draw.rect(screen, (0,0,0), rect, 1)

 
        screen.blit(font.render(message, True, (0,0,0)), (20, 520))

        # Events
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                # Switch Mode
                if event.key == pygame.K_t:
                    mode = "PATH" if mode == "DP" else "DP"

                # Run Pathfinding
                if event.key == pygame.K_SPACE and mode == "PATH":
                    visited, path = astar(grid, start, end)

                # Reset Path Grid
                if event.key == pygame.K_r:
                    grid = [[0 for _ in range(cols)] for _ in range(rows)]
                    visited = []
                    path = []

            if pygame.mouse.get_pressed()[0] and mode == "PATH":

                mx, my = pygame.mouse.get_pos()

                x = (my - 100) // size
                y = (mx - 200) // size

                if 0 <= x < rows and 0 <= y < cols:
                    if (x, y) != start and (x, y) != end:
                        grid[x][y] = 1

        pygame.display.flip()
        clock.tick(30)