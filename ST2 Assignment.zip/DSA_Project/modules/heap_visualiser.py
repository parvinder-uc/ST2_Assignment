import pygame
import random


class MinHeap:

    def __init__(self):
        self.heap = []

    def insert(self, val):
        self.heap.append(val)
        self._bubble_up(len(self.heap) - 1)

    def _bubble_up(self, index):

        parent = (index - 1) // 2

        if index > 0 and self.heap[index] < self.heap[parent]:
            self.heap[index], self.heap[parent] = self.heap[parent], self.heap[index]
            self._bubble_up(parent)

    def extract_min(self):

        if len(self.heap) == 0:
            return None

        if len(self.heap) == 1:
            return self.heap.pop()

        root = self.heap[0]

        self.heap[0] = self.heap.pop()
        self._heapify_down(0)

        return root

    def _heapify_down(self, index):

        smallest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < len(self.heap) and self.heap[left] < self.heap[smallest]:
            smallest = left

        if right < len(self.heap) and self.heap[right] < self.heap[smallest]:
            smallest = right

        if smallest != index:
            self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
            self._heapify_down(smallest)


# Button Class
class Button:
    def __init__(self, x, y, w, h, text):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text

    def draw(self, screen, font):
        pygame.draw.rect(screen, (40, 40, 40), self.rect)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)

        txt = font.render(self.text, True, (255, 255, 255))
        screen.blit(txt, (self.rect.x + 10, self.rect.y + 10))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def heap_module(screen, clock):

    font = pygame.font.SysFont(None, 24)

    min_heap = MinHeap()

    message = "HEAP MODE"

    # Buttons
    btn_insert = Button(20, 620, 140, 40, "INSERTs")
    btn_extract = Button(180, 620, 140, 40, "EXTRACT")
    btn_reset = Button(340, 620, 140, 40, "RESET")
    btn_menu = Button(500, 620, 140, 40, "MENU")

    running = True

    while running:

        screen.fill((255, 255, 255))

        # TEXT
        screen.blit(font.render(message, True, (50, 50, 50)), (20, 20))

        positions = {}

        # Tree Positing
        if len(min_heap.heap) > 0:

            level_height = 90
            screen_width = 800

            for i, val in enumerate(min_heap.heap):

                level = i.bit_length() - 1
                level_start = (2 ** level) - 1
                pos_in_level = i - level_start
                level_width = 2 ** level

                spacing = screen_width // (level_width + 1)

                x = spacing * (pos_in_level + 1)
                y = 120 + level * level_height

                positions[i] = (int(x), int(y))
                
        for i, val in enumerate(min_heap.heap):

            if i in positions:

                x, y = positions[i]

                pygame.draw.circle(screen, (200, 150, 255), (x, y), 20)
                pygame.draw.circle(screen, (0, 0, 0), (x, y), 20, 2)

                txt = font.render(str(val), True, (0, 0, 0))
                screen.blit(txt, (x - 10, y - 10))

        # Draw button
        btn_insert.draw(screen, font)
        btn_extract.draw(screen, font)
        btn_reset.draw(screen, font)
        btn_menu.draw(screen, font)

        # EVENTS
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                # Insert
                if btn_insert.clicked(pos):
                    val = random.randint(1, 99)
                    min_heap.insert(val)
                    message = f"Inserted {val}"

                # Extract
                if btn_extract.clicked(pos):
                    removed = min_heap.extract_min()
                    message = f"Extracted {removed}" if removed else "Heap Empty"

                # Reset
                if btn_reset.clicked(pos):
                    min_heap = MinHeap()
                    message = "Heap Reset"

                # Menu
                if btn_menu.clicked(pos):
                    running = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_i:
                    val = random.randint(1, 99)
                    min_heap.insert(val)
                    message = f"Inserted {val}"
                if event.key == pygame.K_e:
                    removed = min_heap.extract_min()
                    message = f"Extracted {removed}" if removed else "Heap Empty"
                if event.key == pygame.K_r:
                    min_heap = MinHeap()
                    message = "Heap Reset"

        pygame.display.flip()
        clock.tick(30)