import pygame
import random


# Merge sort Function
def merge(array, left, mid, right, draw_callback, screen, clock):

    left_part = array[left:mid + 1]
    right_part = array[mid + 1:right + 1]
    i = 0
    j = 0
    k = left

    while i < len(left_part) and j < len(right_part):

        if left_part[i] <= right_part[j]:
            array[k] = left_part[i]
            i += 1
        else:
            array[k] = right_part[j]
            j += 1

        draw_callback(array, k)
        pygame.display.flip()
        clock.tick(20)
        k += 1

    while i < len(left_part):
        array[k] = left_part[i]
        i += 1
        draw_callback(array, k)
        pygame.display.flip()
        clock.tick(20)
        k += 1

    while j < len(right_part):
        array[k] = right_part[j]
        j += 1
        draw_callback(array, k)
        pygame.display.flip()
        clock.tick(20)
        k += 1


def merge_sort(array, left, right, draw_callback, screen, clock):

    if left < right:
        mid = (left + right) // 2
        merge_sort(array, left, mid, draw_callback, screen, clock)
        merge_sort(array, mid + 1, right, draw_callback, screen, clock)
        merge(array, left, mid, right, draw_callback, screen, clock)


# Buttons Class
class Button:
    def __init__(self, x, y, w, h, text):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text

    def draw(self, screen, font):
        pygame.draw.rect(screen, (40, 40, 40), self.rect)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)

        txt = font.render(self.text, True, (255, 255, 255))
        screen.blit(txt, (self.rect.x + 10, self.rect.y + 10))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def sorting_module(screen, clock):

    font = pygame.font.SysFont(None, 24)

    # Array
    n = 25
    array = [random.randint(50, 450) for _ in range(n)]

    sorting = False
    algorithms = ["BUBBLE", "SELECTION", "MERGE"]
    current_algorithm = 0
    algorithm = algorithms[current_algorithm]

    i = 0
    j = 0
    min_idx = 0

    message = f"Mode: {algorithm}"

    # Draw Function
    def draw_array(arr, highlight=-1):

        screen.fill((255, 255, 255))

        screen.blit(font.render(message, True, (50, 50, 50)), (20, 20))

        for idx, val in enumerate(arr):

            color = (150, 150, 150)

            if idx == highlight:
                color = (255, 100, 100)

            pygame.draw.rect(screen, color, (70 + idx * 28, 550 - val, 22, val))

    # Buttons
    btn_start = Button(20, 600, 120, 40, "START")
    btn_toggle = Button(160, 600, 120, 40, "TOGGLE")
    btn_reset = Button(300, 600, 120, 40, "RESET")
    btn_menu = Button(440, 600, 120, 40, "MENU")

    running = True

    while running:

        draw_array(array)

        # Sorting Logic
        if sorting:

            if algorithm == "BUBBLE":
                if i < n:
                    if j < n - i - 1:
                        if array[j] > array[j + 1]:
                            array[j], array[j + 1] = array[j + 1], array[j]

                        draw_array(array, j)
                        j += 1
                    else:
                        j = 0
                        i += 1
                else:
                    sorting = False
                    message = "Bubble Sort Complete"
            elif algorithm == "SELECTION":
                if i < n - 1:
                    if j < n:
                        if array[j] < array[min_idx]:
                            min_idx = j

                        draw_array(array, j)
                        j += 1
                    else:
                        array[i], array[min_idx] = array[min_idx], array[i]
                        i += 1
                        min_idx = i
                        j = i + 1
                else:
                    sorting = False
                    message = "Selection Sort Complete"

            elif algorithm == "MERGE":
                merge_sort(array, 0, len(array) - 1, draw_array, screen, clock)
                sorting = False
                message = "Merge Sort Complete"

        # Draw Buttons
        btn_start.draw(screen, font)
        btn_toggle.draw(screen, font)
        btn_reset.draw(screen, font)
        btn_menu.draw(screen, font)

        # Events
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                # Start
                if btn_start.clicked(pos) and not sorting:
                    sorting = True
                    i = 0
                    j = 0
                    min_idx = 0

                # ToggleGLE
                if btn_toggle.clicked(pos) and not sorting:
                    current_algorithm = (current_algorithm + 1) % len(algorithms)
                    algorithm = algorithms[current_algorithm]
                    message = f"Mode: {algorithm}"

                # Reset
                if btn_reset.clicked(pos):
                    array = [random.randint(50, 450) for _ in range(n)]
                    i = 0
                    j = 0
                    min_idx = 0
                    sorting = False
                    message = f"Mode: {algorithm}"

                # Menu
                if btn_menu.clicked(pos):
                    running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                if event.key == pygame.K_s and not sorting:
                    sorting = True
                    i = 0
                    j = 0
                    min_idx = 0
                if event.key == pygame.K_t and not sorting:
                    current_algorithm = (current_algorithm + 1) % len(algorithms)
                    algorithm = algorithms[current_algorithm]
                if event.key == pygame.K_r:
                    array = [random.randint(50, 450) for _ in range(n)]
                    i = 0
                    j = 0
                    min_idx = 0
                    sorting = False

        pygame.display.flip()
        clock.tick(60)