import pygame

# DFS Function
def dfs(graph, node, visited):

    if node not in visited:
        visited.append(node)

        for neighbor in graph[node]:
            dfs(graph, neighbor, visited)


# Buttons Class
class Button:
    def __init__(self, x, y, w, h, text):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text

    def draw(self, screen, font):
        pygame.draw.rect(screen, (40, 40, 40), self.rect)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)
        txt = font.render(self.text, True, (255, 255, 255))
        screen.blit(txt, (self.rect.x + 10, self.rect.y + 10))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def graphs_module(screen, clock):

    font = pygame.font.SysFont(None, 24)

    nodes_pos = {
        'A': (150, 150),
        'B': (300, 100),
        'C': (150, 300),
        'D': (300, 300),
        'E': (450, 200),
        'F': (600, 200)
    }

    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'D'],
        'D': ['B', 'C', 'E'],
        'E': ['B', 'D', 'F'],
        'F': ['E']
    }

    #array
    visited = []
    queue = []
    searching = False
    search_mode = None

    message = "( BFS ) ( DFS ) ( RESET ) ( MENU )"

    # Buttons
    btn_bfs = Button(20, 520, 120, 40, "BFS")
    btn_dfs = Button(160, 520, 120, 40, "DFS")
    btn_reset = Button(300, 520, 120, 40, "RESET")
    btn_menu = Button(440, 520, 120, 40, "MENU")

    running = True

    while running:

        screen.fill((255, 255, 255))

        # Draw Edges
        for start_node, neighbors in graph.items():
            for end_node in neighbors:
                pygame.draw.line(
                    screen,
                    (180, 180, 180),
                    nodes_pos[start_node],
                    nodes_pos[end_node],
                    2
                )

        # Draw Nodes
        for node, pos in nodes_pos.items():

            color = (220, 220, 220)
            if node in visited:
                color = (100, 255, 100)
            elif node in queue:
                color = (255, 255, 100)

            pygame.draw.circle(screen, color, pos, 25)
            pygame.draw.circle(screen, (0, 0, 0), pos, 25, 2)
            node_txt = font.render(node, True, (0, 0, 0))
            screen.blit(node_txt, (pos[0] - 8, pos[1] - 10))

        screen.blit(font.render(message, True, (50, 50, 50)), (20, 20))

        # Draw Buttons
        btn_bfs.draw(screen, font)
        btn_dfs.draw(screen, font)
        btn_reset.draw(screen, font)
        btn_menu.draw(screen, font)

        # Events
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                # BFS Button
                if btn_bfs.clicked(pos) and not searching:
                    searching = True
                    search_mode = "BFS"
                    visited = []
                    queue = ['A']
                    message = "BFS Running"

                # DFS Button
                if btn_dfs.clicked(pos) and not searching:
                    visited = []
                    dfs(graph, 'A', visited)
                    searching = False
                    search_mode = "DFS"
                    message = "DFS Complete"

                # Reset Button
                if btn_reset.clicked(pos):
                    visited = []
                    queue = []
                    searching = False
                    search_mode = None
                    message = "( BFS ) ( DFS ) ( RESET ) ( MENU )"

                # Menu Buttons
                if btn_menu.clicked(pos):
                    running = False
            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                if event.key == pygame.K_b and not searching:
                    searching = True
                    search_mode = "BFS"
                    visited = []
                    queue = ['A']
                    message = "BFS Running"

                if event.key == pygame.K_d and not searching:
                    visited = []
                    dfs(graph, 'A', visited)
                    searching = False
                    search_mode = "DFS"
                    message = "DFS Complete"

                if event.key == pygame.K_r:
                    visited = []
                    queue = []
                    searching = False
                    search_mode = None
                    message = "( BFS ) ( DFS ) ( RESET ) ( MENU )"

        # BFS Logic
        if searching and search_mode == "BFS":

            if queue:

                pygame.time.delay(600)
                current = queue.pop(0)

                if current not in visited:
                    visited.append(current)
                    for neighbor in graph[current]:
                        if neighbor not in visited and neighbor not in queue:
                            queue.append(neighbor)

            else:
                searching = False
                message = "BFS Complete"

        pygame.display.flip()
        clock.tick(30)