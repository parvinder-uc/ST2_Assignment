import pygame
import random

# Node
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.left = None
        self.right = None

# Stack
class Stack:
    
    def __init__(self):
        self.items = []
    def push(self, item):
        self.items.append(item)
    def pop(self):
        if self.items:
            return self.items.pop()
        return None

# Queue
class Queue:
    def __init__(self):
        self.items = []

    def enqueue(self, item):
        self.items.insert(0, item)
    def dequeue(self):
        if self.items:
            return self.items.pop()
        return None

# BST
def insert_bst(root, data):
    if root is None:
        return Node(data)

    if data < root.data:
        root.left = insert_bst(root.left, data)
    else:
        root.right = insert_bst(root.right, data)

    return root

# Draw Tree
def draw_tree(screen, node, x, y, spacing, font):
    if node:
        if node.left:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x - spacing, y + 60), 2)
            draw_tree(screen, node.left, x - spacing, y + 60, spacing // 2, font)
        if node.right:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x + spacing, y + 60), 2)
            draw_tree(screen, node.right, x + spacing, y + 60, spacing // 2, font)
        pygame.draw.circle(screen, (255, 200, 100), (x, y), 20)
        pygame.draw.circle(screen, (0, 0, 0), (x, y), 20, 2)

        txt = font.render(str(node.data), True, (0, 0, 0))
        screen.blit(txt, (x - 10, y - 10))

# Button
class Button:
    def __init__(self, x, y, w, h, text):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text

    def draw(self, screen, font):
        pygame.draw.rect(screen, (30, 30, 30), self.rect)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)
        txt = font.render(self.text, True, (255, 255, 255))
        screen.blit(txt, (self.rect.x + 10, self.rect.y + 10))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

# Main
def data_structures_module(screen, clock):
    font = pygame.font.SysFont(None, 28)

    stack = Stack()
    queue = Queue()
    bst_root = None
    mode = "STACK"
    running = True

    # Buttons
    btn_push = Button(20, 550, 140, 40, "PUSH")
    btn_pop = Button(170, 550, 140, 40, "POP")
    btn_enqueue = Button(20, 550, 140, 40, "ENQUEUE")
    btn_dequeue = Button(170, 550, 140, 40, "DEQUEUE")
    btn_toggle = Button(320, 550, 140, 40, "TOGGLE")
    btn_menu = Button(470, 550, 140, 40, "MENU")

    while running:
        screen.fill((255, 255, 255))

        screen.blit(font.render(f"Mode: {mode}", True, (0, 0, 0)), (20, 20))
        screen.blit(font.render(f"{mode} MODE", True, (50, 50, 50)), (20, 50))

        # Buttons Dispay Logic
        if mode == "STACK":
            btn_push.draw(screen, font)
            btn_pop.draw(screen, font)

        elif mode == "QUEUE":
            btn_enqueue.draw(screen, font)
            btn_dequeue.draw(screen, font)

        elif mode == "BST":
            btn_push.draw(screen, font)

        btn_toggle.draw(screen, font)
        btn_menu.draw(screen, font)

        # Visuls
        if mode == "STACK":
            pygame.draw.rect(screen, (0, 0, 0), (300, 150, 200, 350), 2)

            for i, v in enumerate(stack.items):
                rect = pygame.Rect(310, 460 - (i * 45), 180, 40)
                pygame.draw.rect(screen, (100, 150, 250), rect)
                txt = font.render(str(v), True, (255, 255, 255))
                screen.blit(txt, (rect.x + 70, rect.y + 10))

        elif mode == "QUEUE":
            for i, v in enumerate(queue.items):
                rect = pygame.Rect(310 + (i * 50), 300, 40, 40)
                pygame.draw.rect(screen, (200, 120, 120), rect)
                txt = font.render(str(v), True, (255, 255, 255))
                screen.blit(txt, (rect.x + 10, rect.y + 10))

        elif mode == "BST":
            if bst_root:
                draw_tree(screen, bst_root, 400, 150, 150, font)

        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                val = random.randint(1, 99)

                # Stack
                if mode == "STACK":
                    if btn_push.is_clicked(pos):
                        stack.push(val)
                    if btn_pop.is_clicked(pos):
                        stack.pop()

                # Queue
                elif mode == "QUEUE":
                    if btn_enqueue.is_clicked(pos):
                        queue.enqueue(val)
                    if btn_dequeue.is_clicked(pos):
                        queue.dequeue()

                # BST
                elif mode == "BST":
                    if btn_push.is_clicked(pos):
                        bst_root = insert_bst(bst_root, val)

                # Common
                if btn_toggle.is_clicked(pos):
                    modes = ["STACK", "QUEUE", "BST"]
                    mode = modes[(modes.index(mode) + 1) % len(modes)]

                if btn_menu.is_clicked(pos):
                    running = False

        pygame.display.flip()
        clock.tick(30)